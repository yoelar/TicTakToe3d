﻿// backend/src/components/TicTacToeGame.ts
import { Game, MoveResult } from './Game';
import { TicTacToePlayer } from './TicTacToePlayer';

export interface TicTacToeMove {
    x: number;
    y: number;
    z?: number;
}

export abstract class TicTacToeGame extends Game<TicTacToePlayer> {
    protected currentPlayerSign: 'X' | 'O' = 'X';

    // ✅ Helper: solo mode is when less than 2 players exist
    isSoloMode(): boolean {
        return this.players.length < 2;
    }

    // ✅ Encapsulated player management
    addPlayer(player: TicTacToePlayer): void {
        if (this.players.length >= 2) {
            throw new Error('Game full');
        }
        this.players.push(player);
    }

    getPlayers(): TicTacToePlayer[] {
        return [...this.players];
    }

    /**
     * Allows a client to join this game.
     */
    joinPlayer(clientId: string): { success: boolean; player?: 'X' | 'O'; error?: string } {
        // Already joined?
        const existing = this.players.find(p => p.id === clientId);
        if (existing) {
            return { success: false, error: 'Player already joined' };
        }

        // Reject if full
        if (this.players.length >= 2) {
            return { success: false, error: 'Game full' };
        }

        // Determine sign
        const existingSigns = this.players.map(p => p.sign);
        const newSign: 'X' | 'O' = existingSigns.includes('X') ? 'O' : 'X';
        const newPlayer = new TicTacToePlayer(clientId, newSign);
        this.addPlayer(newPlayer);

        // Ensure X starts when both are present
        if (this.players.length === 2) {
            this.currentPlayerSign = 'X';
        }

        return { success: true, player: newSign };
    }

    export function removePlayer(clientId: string) {

        const playerIndex = this.players.findIndex(p => p.id === clientId);
        if (playerIndex === -1) {
            return { success: false, error: 'Player not found in this game' };
        }

        // Remove the player from the list
        const [removedPlayer] = this.players.splice(playerIndex, 1);

        return {
            success: true,
            remainingPlayers: this.players.map(p => ({ id: p.id, sign: p.sign })),
            soloMode: game.isSoloMode(),
        };
    }

    /**
     * Abstracts over move logic, implemented in subclasses.
     */
    abstract makeMove(player: TicTacToePlayer, moveData: TicTacToeMove): MoveResult;
}
