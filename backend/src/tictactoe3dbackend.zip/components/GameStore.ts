﻿// backend/src/components/GameStore.ts
import { ThreeDTicTacToeGame } from './ThreeDTicTacToeGame';
import { TicTacToePlayer } from './TicTacToePlayer';
import { randomUUID } from 'crypto';

export const games: Record<string, ThreeDTicTacToeGame> = {};

/**
 * Creates a new 3D TicTacToe game for the given clientId.
 */
export function createGame(clientId: string) {
    const gameId = randomUUID();
    const game = new ThreeDTicTacToeGame(gameId);
    const player = new TicTacToePlayer(clientId, 'X');

    game.addPlayer(player);
    games[gameId] = game;

    return {
        success: true,
        gameId,
        player: 'X' as const,
        playerId: clientId,
    };
}

/**
 * Allows another client to join an existing game.
 */
export function joinGame(gameId: string, clientId: string) {
    const game = games[gameId];
    if (!game) {
        return { success: false, error: 'Game not found' };
    }

    const result = game.joinPlayer(clientId);
    return result.success
        ? { success: true, player: result.player, playerId: clientId }
        : { success: false, error: result.error };
}

/**
 * Handles a move request from a player.
 */
export function makeMove(gameId: string, clientId: string, moveData: any) {
    const game = games[gameId];
    if (!game) {
        return { success: false, error: 'Game not found' };
    }

    const player = game.getPlayers().find(p => p.id === clientId);
    if (!player) {
        return { success: false, error: 'Invalid playerId' };
    }

    const result = game.makeMove(player, moveData);

    return {
        success: result.success,
        error: result.error,
        state: game.serialize(),
    };
}


/**
 * Handles a player leaving a game.
 */
export function leaveGame(gameId: string, clientId: string) {
    const game = games[gameId];
    if (!game) {
        return { success: false, error: 'Game not found' };
    }
    return game.removePlayer(clientId);
}
